namespace OneOf
{
    public interface IOneOf 
    { 
        object Value { get ; }
        int Index { get; }
    }
}